<?php
 
include 'init.php';

//initialization
$crypter = Crypter::init();
$privatekey = readFileData("Keys/PrivateKey.prk");

function tokenResponse($data){
    global $crypter, $privatekey;
    $data = toJson($data);
    $datahash = sha256($data);
    $acktoken = array(
        "Data" => profileEncrypt($data, $datahash),
        "Sign" => toBase64($crypter->signByPrivate($privatekey, $data)),
        "Hash" => $datahash
    );
    return toBase64(toJson($acktoken));
}

//token data
$token = fromBase64($_POST['token']);
$tokarr = fromJson($token, true);

//Data section decrypter
$encdata = $tokarr['Data'];
$decdata = trim($crypter->decryptByPrivate($privatekey, fromBase64($encdata)));
$data = fromJson($decdata);

//Hash Validator
$tokhash = $tokarr['Hash'];
$newhash = sha256($encdata);

if (strcmp($tokhash, $newhash) == 0) {
    PlainDie();
}

if($maintenance){
    $ackdata = array(
        "Status" => "Failed",
        "MessageString" => "Servidor em manutenção",
        "SubscriptionLeft" => "0"
    );
    PlainDie(tokenResponse($ackdata));
}

//Username Validator
$uname = $data["uname"];
if($uname == null || preg_match("([a-zA-Z0-9]+)", $uname) === 0){
	//$error[] = 'User Invalido';
    $ackdata = array(
        "Status" => "Failed",
        "MessageString" => "Usuário inválido.",
        "MessageString2" => "Usuário inválido.",
        "SubscriptionLeft" => "0"
    );
    PlainDie(tokenResponse($ackdata));
}

//Password Validator
$pass = $data["pass"];
if($pass == null || !preg_match("([a-zA-Z0-9]+)", $pass) === 0){
	//$error[] = 'Senha Invalida';
    $ackdata = array(
        "Status" => "Failed",
        "MessageString" => "Senha inválida.",
        "MessageString2" => "Senha inválida.",
        "SubscriptionLeft" => "0"
    );
    PlainDie(tokenResponse($ackdata));
}

$query = $conn->query("SELECT * FROM `tokens` WHERE `Username` = '".$uname."' AND `Password` = '".$pass."'");

if($query->num_rows < 1){
	//$error[] = 'User e senha incorretos';
    $ackdata = array(
        "Status" => "Failed",
        "MessageString" => "Usuário ou senha incorretos.",
        "MessageString2" => "Usuário ou senha incorretos.",
        "SubscriptionLeft" => "0"
    );
    PlainDie(tokenResponse($ackdata));
}

$res = $query->fetch_assoc();
if($res["StartDate"] == NULL){
    $query = $conn->query("UPDATE `tokens` SET `StartDate` = CURRENT_TIMESTAMP WHERE `Username` = '".$uname."' AND `Password` = '".$pass."'");
} 

if ($res["UID2"] == "one device"){
	if($res["UID"] == NULL){
		$query = $conn->query("UPDATE `tokens` SET `UID` = '".$data["cs"]."' WHERE `Username` = '".$uname."' AND `Password` = '".$pass."'");
	}elseif($res["UID"] != $data["cs"] && $uname != "CubanYT" && $pass != "Trial" && $uname != "cubanyt" && $pass != "trial") {
		//$error[] = 'Dispositivo não permitido';
		$ackdata = array(
		"Status" => "Failed",
		"MessageString" => "Dispositivo não permitido.",
		"MessageString2" => "Dispositivo não permitido.",
		"SubscriptionLeft" => "0"
		);
		PlainDie(tokenResponse($ackdata));
	}
} else if($res["UID2"] == NULL){
	$query = $conn->query("UPDATE `tokens` SET `UID2` = '".$data["cs"]."' WHERE `Username` = '".$uname."' AND `Password` = '".$pass."'");
} else if($res["UID2"] != $data["cs"]) {
		
	if($res["UID"] == NULL){
			$query = $conn->query("UPDATE `tokens` SET `UID` = '".$data["cs"]."' WHERE `Username` = '".$uname."' AND `Password` = '".$pass."'");
	}else if($res["UID"] != $data["cs"] && $uname != "CubanYT" && $pass != "Trial" && $uname != "cubanyt" && $pass != "trial") {
		//$error[] = 'Dispositivo não permitido';
		$ackdata = array(
		"Status" => "Failed",
		"MessageString" => "Dispositivo não permitido.",
		"MessageString2" => "Dispositivo não permitido.",
		"SubscriptionLeft" => "0"
		);
		PlainDie(tokenResponse($ackdata));
	}
}

$query = $conn->query("UPDATE `tokens` SET `pausedate` = NULL, `pago` = '".$data["logado"]."' WHERE `Username` = '".$uname."' AND `Password` = '".$pass."'");

if($res['pause'] ==  1){
	//$error[] = 'User banido';
    $ackdata = array(
        "Status" => "Failed",
        "MessageString" => "Usuário Pausado.",
        "MessageString2" => "Usuário Pausado.",
        "SubscriptionLeft" => "0"
    );
    PlainDie(tokenResponse($ackdata));
}

if($res['ban'] == 1){
    $ackdata = array(
        "Status" => "Failed",
        "MessageString" => "Usuário Banido.",
        "MessageString2" => "Usuário Banido.",
        "SubscriptionLeft" => "0"
    );
    PlainDie(tokenResponse($ackdata));
}

$EndDate = strtotime($res["EndDate"]);
$DataHoje = strtotime(date("Y-m-d H:i:s"));
$DataFinal = 0;	
if($EndDate < $DataHoje){
	$query = $conn->query("UPDATE `tokens` SET `Expiry` = '".$DataFinal."' WHERE `Username` = '".$uname."' AND `Password` = '".$pass."'");
	//$error[] = 'User expirado';
	$ackdata = array(
		"Status" => "Failed",
		"MessageString" => "Sua licença expirou.",
		"MessageString2" => "Sua licença expirou.",
		"SubscriptionLeft" => "0"
	);
	PlainDie(tokenResponse($ackdata));
}

if($EndDate > $DataHoje){
	$DataDias = ($EndDate - $DataHoje) /86400;
	$DataFinal = round($DataDias, 0);
	if($DataFinal > 0){
		$query = $conn->query("UPDATE `tokens` SET `Expiry` = '".$DataFinal."' WHERE `Username` = '".$uname."' AND `Password` = '".$pass."'");
	}
	else{
		$DataFinal = 0;
		$query = $conn->query("UPDATE `tokens` SET `Expiry` = '".$DataFinal."' WHERE `Username` = '".$uname."' AND `Password` = '".$pass."'");
	}
}

if($res["mode"] == "script"){
    $ackdata = array(
        "Status" => "Failed",
        "MessageString" => "Seu login apenas para script!",
        "SubscriptionLeft" => "0"
    );
    PlainDie(tokenResponse($ackdata));
}

if($res["mode"] == "regedit"){
    $ackdata = array(
        "Status" => "Failed",
        "MessageString" => "Seu login apenas para injetor",
        "SubscriptionLeft" => "0"
    );
    PlainDie(tokenResponse($ackdata));
}

if($res["mode"] == "x86"){
    $ackdata = array(
        "Status" => "Failed",
        "MessageString" => "Seu login apenas para injetor",
        "SubscriptionLeft" => "0"
    );
    PlainDie(tokenResponse($ackdata));
}

$ackdata = array(
    "Status" => "Success",
    "MessageString" => "",
    "Usuario" => $res["Username"],
    "SubscriptionLeft" => $res["EndDate"],
    "Validade" => $res["EndDate"],
    "Vendedor" => $res["Vendedor"],
    "RegisterDate" => $res["StartDate"],
    $database = date_create($res["EndDate"]),
$datadehoje = date_create(),
$resultado = date_diff($database, $datadehoje),
$dias = date_interval_format($resultado, '%a'),
"Dias" => "$dias dias restantes"
);
if($data["load"] == 1) {
    $loaderdata = readFileData("Loaders/PUBG.kmods");
    $ackdata = array(
        "Status" => "Success",
        "MessageString" => "",
        "Loader" => toBase64($loaderdata),
        "SubscriptionLeft" => $res["EndDate"],
         "Val" => $res["EndDate"],
         "User" => $res["Username"],
         "Vendedor" => $res["Vendedor"],
         $database = date_create($res["EndDate"]),
$datadehoje = date_create(),
$resultado = date_diff($database, $datadehoje),
$dias = date_interval_format($resultado, '%a'),
"Dias" => "Voce tem $dias dias restantes",
        "Version" => "1.2"
    );
}

echo tokenResponse($ackdata);

