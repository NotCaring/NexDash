{
"title": "  HG CHEATS REGEDIT MOBILE E EMULADOR",

"vendedores":"VENDEDORES OFICIAIS
<p> ► HORUS (DONO) : │<a href=\"https://api.whatsapp.com/send?phone=+5511934336920&text=Quero%20Comprar%20a regedit\"> CLICK AQUI<p>
<p> ► BK (MODS) : │<a href=\"https://api.whatsapp.com/send?phone=+5521980408222&text=Quero%20Comprar%20a regedit\"> CLICK AQUI<p>
<p> ► MANDRACK (MODS) : │<a href=\"https://api.whatsapp.com/send?phone=+5512991587554&text=Quero%20Comprar%20a regedit\"> CLICK AQUI<p>
<p> ► DOLLY (MODS) : │<a href=\"https://api.whatsapp.com/send?phone=+7199007284&text=Quero%20Comprar%20a regedit\"> CLICK AQUI<p>
"}
