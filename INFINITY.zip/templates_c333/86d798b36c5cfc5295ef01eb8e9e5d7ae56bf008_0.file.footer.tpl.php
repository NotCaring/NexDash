<?php
/* Smarty version 3.1.38, created on 2022-01-24 01:29:22
  from '/home/u129344762/domains/ninjacheat.xyz/public_html/CHEAT/Ninja/templates/core/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_61ee2b22304f21_02613869',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '86d798b36c5cfc5295ef01eb8e9e5d7ae56bf008' => 
    array (
      0 => '/home/u129344762/domains/ninjacheat.xyz/public_html/CHEAT/Ninja/templates/core/footer.tpl',
      1 => 1642997245,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61ee2b22304f21_02613869 (Smarty_Internal_Template $_smarty_tpl) {
?>				<div class="app-wrapper-footer">
					<div class="app-footer">
						<div class="app-footer__inner">
							<div class="app-footer-left">
							  Copyright © <?php echo $_smarty_tpl->tpl_vars['title']->value;?>

							</div>
						</div>
					</div>
				</div> 
			</div> 
		</div> 
    </div> 
	<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
assets/scripts/main.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="http://code.jquery.com/jquery-1.9.1.js"><?php echo '</script'; ?>
>
	</body>
</html><?php }
}
