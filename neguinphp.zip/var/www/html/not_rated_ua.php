<?php

$not_rated_ua = array(
        'CleanTalk Uptime bot.+',
        'Googlebot', 
        'Bingbot',
        'Baiduspider',
        'YandexBot',
        'facebot',
        'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)',
        'ia_archiver'
);

?>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2231403447373783"
     crossorigin="anonymous"></script>