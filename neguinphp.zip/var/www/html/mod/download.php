<?php 

header('location: https://mega.nz/file/u6RmWQZR#1JGPhC7FdO8hxjI2SFmTgKBJDN2CFhOUHw_2TprxOTQ');
